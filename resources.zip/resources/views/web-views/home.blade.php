@extends('layouts.front-end.app')

@section('title', $web_config['name']->value.' '.\App\CPU\translate('Online Shopping').' | '.$web_config['name']->value.' '.\App\CPU\translate(' Ecommerce'))

@push('css_or_js')
    <meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="og:title" content="Welcome To {{$web_config['name']->value}} Home"/>
    <meta property="og:url" content="{{env('APP_URL')}}">
    <meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="twitter:title" content="Welcome To {{$web_config['name']->value}} Home"/>
    <meta property="twitter:url" content="{{env('APP_URL')}}">
    <meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/home.css"/>
    <style>
        .cz-countdown-days {
            border: .5px solid{{$web_config['primary_color']}};
        }

        .btn-scroll-top {
            background: {{$web_config['primary_color']}};
        }

        .__best-selling:hover .ptr,
        .flash_deal_product:hover .flash-product-title {
            color: {{$web_config['primary_color']}};
        }

        .cz-countdown-hours {
            border: .5px solid{{$web_config['primary_color']}};
        }

        .cz-countdown-minutes {
            border: .5px solid{{$web_config['primary_color']}};
        }

        .cz-countdown-seconds {
            border: .5px solid{{$web_config['primary_color']}};
        }

        .flash_deal_product_details .flash-product-price {
            color: {{$web_config['primary_color']}};
        }

        .featured_deal_left {
            background: {{$web_config['primary_color']}} 0% 0% no-repeat padding-box;
        }

        .category_div:hover {
            color: {{$web_config['secondary_color']}};
        }

        .deal_of_the_day {
            background: {{$web_config['secondary_color']}};
        }

        .best-selleing-image {
            background: {{$web_config['primary_color']}}10;
        }

        .top-rated-image {
            background: {{$web_config['primary_color']}}10;
        }

        @media (max-width: 800px) {
            .categories-view-all {
            {{session('direction') === "rtl" ? 'margin-left: 10px;' : 'margin-right: 6px;'}}

            }

            .categories-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 0px;' : 'margin-left: 6px;'}}

            }

            .seller-list-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 0px;' : 'margin-left: 10px;'}}

            }

            .seller-list-view-all {
            {{Session::get('direction') === "rtl" ? 'margin-left: 20px;' : 'margin-right: 10px;'}}

            }

            .category-product-view-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 16px;' : 'margin-left: -8px;'}}

            }

            .category-product-view-all {
            {{Session::get('direction') === "rtl" ? 'margin-left: -7px;' : 'margin-right: 5px;'}}

            }
        }

        @media (min-width: 801px) {
            .categories-view-all {
            {{session('direction') === "rtl" ? 'margin-left: 30px;' : 'margin-right: 27px;'}}

            }

            .categories-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 25px;' : 'margin-left: 25px;'}}

            }

            .seller-list-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 6px;' : 'margin-left: 10px;'}}

            }

            .seller-list-view-all {
            {{Session::get('direction') === "rtl" ? 'margin-left: 12px;' : 'margin-right: 10px;'}}

            }

            .seller-card {
            {{Session::get('direction') === "rtl" ? 'padding-left:0px !important;' : 'padding-right:0px !important;'}}

            }

            .category-product-view-title {
            {{Session::get('direction') === "rtl" ? 'margin-right: 10px;' : 'margin-left: -12px;'}}

            }

            .category-product-view-all {
            {{Session::get('direction') === "rtl" ? 'margin-left: -20px;' : 'margin-right: 0px;'}}

            }
        }

        .countdown-card {
            background: {{$web_config['primary_color']}}10;

        }

        .flash-deal-text {
            color: {{$web_config['primary_color']}};
        }

        .countdown-background {
            background: {{$web_config['primary_color']}};
        }

        }
        .czi-arrow-left {
            color: {{$web_config['primary_color']}};
            background: {{$web_config['primary_color']}}10;
        }

        .czi-arrow-right {
            color: {{$web_config['primary_color']}};
            background: {{$web_config['primary_color']}}10;
        }

        .flash-deals-background-image {
            background: {{$web_config['primary_color']}}10;
        }

        .view-all-text {
            color: {{$web_config['secondary_color']}}  !important;
        }

        .feature-product .czi-arrow-left {
            color: {{$web_config['primary_color']}};
            background: {{$web_config['primary_color']}}10
        }

        .feature-product .czi-arrow-right {
            color: {{$web_config['primary_color']}};
            background: {{$web_config['primary_color']}}10;
            font-size: 12px;
        }

        /*  */
    </style>

    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.carousel.min.css"/>
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.theme.default.min.css"/>
@endpush

@section('content')
    <div id="sliders-container" class="fusion-slider-visibility"> </div>
            <main id="main" class="clearfix width-100">
                <div class="fusion-row" style="max-width:100%;">
                    <section id="content" class="full-width">
                        <div id="post-12951" class="post-12951 page type-page status-publish has-post-thumbnail hentry">
                            <span class="entry-title rich-snippet-hidden">Ethical Healing Crystals and Tumbled
                                Stones</span><span class="updated rich-snippet-hidden">2023-08-31T17:01:52-10:00</span>
                            <div class="post-content">
                                <div style="--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-right:0px;--awb-padding-left:0px;--awb-margin-bottom:0px;--awb-min-height:calc(100vh - 150px);--awb-background-image:url(&quot;data:image/gif;base64,R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==&quot;);--awb-background-size:cover;--awb-flex-wrap:wrap;background-attachment:fixed;"
                                    data-preload-img="https://moonrisecrystals.com/wp-content/uploads/Moon-Rise-Cystal-Header.webp"
                                    class="fusion-fullwidth fullwidth-box fusion-builder-row-1 fusion-flex-container has-pattern-background has-mask-background fusion-parallax-fixed hundred-percent-fullwidth non-hundred-percent-height-scrolling nitro-lazy"
                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moon-Rise-Cystal-Header.webp">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-stretch fusion-flex-align-content-space-between fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-0 fusion_builder_column_3_5 3_5 fusion-flex-column"
                                            style="--awb-padding-top:5%;--awb-padding-bottom:18%;--awb-padding-left:15%;--awb-bg-size:cover;--awb-width-large:60%;--awb-margin-top-large:0px;--awb-spacing-right-large:3.2%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:3.2%;--awb-width-medium:60%;--awb-order-medium:0;--awb-margin-top-medium:14%;--awb-spacing-right-medium:3.2%;--awb-margin-bottom-medium:20%;--awb-spacing-left-medium:3.2%;--awb-width-small:100%;--awb-order-small:0;--awb-margin-top-small:13%;--awb-spacing-right-small:1.92%;--awb-margin-bottom-small:20%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-text-color:var(--awb-custom10);--awb-margin-bottom:0px;--awb-margin-bottom-small:0px;--awb-margin-bottom-medium:0px;--awb-font-size:34px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="font-family:&quot;Allura&quot;;font-style:normal;font-weight:400;margin:0;font-size:1em;--fontSize:34;line-height:1.1;">
                                                        Ethically Sourced</h2>
                                                </div>
                                                <div class="fusion-title title fusion-title-2 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-text-color:#fff;--awb-margin-bottom:0px;--awb-font-size:55px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;text-transform:uppercase;--fontSize:55;line-height:1.1;">
                                                        Healing Crystals</h2>
                                                </div>
                                                <div class="fusion-title title fusion-title-3 fusion-sep-none fusion-title-text fusion-title-size-one"
                                                    style="--awb-text-color:var(--awb-custom_color_1);--awb-font-size:18px;">
                                                    <h1 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;letter-spacing:1.4px;text-transform:uppercase;--fontSize:18;--minFontSize:18;line-height:var(--awb-typography1-line-height);">
                                                        Love yourself and your world</h1>
                                                </div>
                                                <div class="fusion-text fusion-text-1"
                                                    style="--awb-text-color:var(--awb-color2);">
                                                    <p>Moonrise Crystals offers healing stones with a transparent supply
                                                        chain, provides free spiritual and scientific resources, and
                                                        gives compassionate support for your healing journey.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-1 fusion_builder_column_2_5 2_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:40%;--awb-margin-top-large:0px;--awb-spacing-right-large:4.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:4.8%;--awb-width-medium:40%;--awb-order-medium:0;--awb-spacing-right-medium:4.8%;--awb-spacing-left-medium:4.8%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-2 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-padding-top:5%;--awb-padding-right:7%;--awb-padding-bottom:7%;--awb-padding-left:10%;--awb-bg-color:rgba(255,255,255,.2);--awb-bg-color-hover:rgba(255,255,255,.2);--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:0;--awb-margin-bottom-large:0px;--awb-spacing-left-large:7.68%;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:0;--awb-spacing-left-medium:7.68%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-4 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-text-color:var(--awb-custom10);">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;text-transform:uppercase;--fontSize:25;line-height:1.3;">
                                                        Beautiful Gems</h3>
                                                </div>
                                                <div class="fusion-text fusion-text-2"
                                                    style="--awb-text-color:var(--awb-color1);">
                                                    <p>Shop our stone collection. Feel the difference that can only come
                                                        from good sourcing.</p>
                                                </div>
                                                <div><a class="fusion-button button-flat button-small button-custom fusion-button-default button-1 fusion-button-default-span fusion-button-default-type"
                                                        style="--button_accent_color:var(--awb-custom10);--button_border_color:var(--awb-custom10);--button_accent_hover_color:var(--awb-color1);--button_border_hover_color:var(--awb-color1);--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_gradient_top_color:rgba(255,255,255,0);--button_gradient_bottom_color:rgba(255,255,255,0);--button_gradient_top_color_hover:var(--awb-color5);--button_gradient_bottom_color_hover:var(--awb-color5);"
                                                        target="_self" href="/shop"><span
                                                            class="fusion-button-text">Shop Crystals</span></a></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-3 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-padding-top:5%;--awb-padding-right:7%;--awb-padding-bottom:7%;--awb-padding-left:10%;--awb-bg-color:rgba(255,255,255,.2);--awb-bg-color-hover:rgba(255,255,255,.2);--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:0;--awb-margin-bottom-large:0px;--awb-spacing-left-large:0;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:0;--awb-spacing-left-medium:0;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-5 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-text-color:var(--awb-custom10);">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;text-transform:uppercase;--fontSize:25;line-height:1.3;">
                                                        Ethical Standards</h3>
                                                </div>
                                                <div class="fusion-text fusion-text-3"
                                                    style="--awb-text-color:var(--awb-color1);">
                                                    <p>8 guidelines to ensure your crystals are consciously sourced to
                                                        protect the environment and workers.</p>
                                                </div>
                                                <div><a class="fusion-button button-flat button-small button-custom fusion-button-default button-2 fusion-button-default-span fusion-button-default-type"
                                                        style="--button_accent_color:var(--awb-custom10);--button_border_color:var(--awb-custom10);--button_accent_hover_color:var(--awb-color1);--button_border_hover_color:var(--awb-color1);--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_gradient_top_color:rgba(255,255,255,0);--button_gradient_bottom_color:rgba(255,255,255,0);--button_gradient_top_color_hover:var(--awb-color5);--button_gradient_bottom_color_hover:var(--awb-color5);"
                                                        target="_self" href="/ethical-crystal/"><span
                                                            class="fusion-button-text">Learn More</span></a></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-4 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-padding-top:5%;--awb-padding-right:7%;--awb-padding-bottom:7%;--awb-padding-left:10%;--awb-bg-color:rgba(255,255,255,.2);--awb-bg-color-hover:rgba(255,255,255,.2);--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:0;--awb-margin-bottom-large:0px;--awb-spacing-left-large:0;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:0;--awb-spacing-left-medium:0;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-6 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-text-color:var(--awb-custom10);">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;text-transform:uppercase;--fontSize:25;line-height:1.3;">
                                                        Crystal Research</h3>
                                                </div>
                                                <div class="fusion-text fusion-text-4"
                                                    style="--awb-text-color:var(--awb-color1);">
                                                    <p>Free access to all our research articles to begin or to deepen
                                                        your healing crystal experience.</p>
                                                </div>
                                                <div><a class="fusion-button button-flat button-small button-custom fusion-button-default button-3 fusion-button-default-span fusion-button-default-type"
                                                        style="--button_accent_color:var(--awb-custom10);--button_border_color:var(--awb-custom10);--button_accent_hover_color:var(--awb-color1);--button_border_hover_color:var(--awb-color1);--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_gradient_top_color:rgba(255,255,255,0);--button_gradient_bottom_color:rgba(255,255,255,0);--button_gradient_top_color_hover:var(--awb-color5);--button_gradient_bottom_color_hover:var(--awb-color5);"
                                                        target="_self" href="/learn-about-crystals/"><span
                                                            class="fusion-button-text">SEE ALL ARTICLES</span></a></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-5 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-padding-top:5%;--awb-padding-right:7%;--awb-padding-bottom:7%;--awb-padding-left:10%;--awb-bg-color:rgba(255,255,255,.2);--awb-bg-color-hover:rgba(255,255,255,.2);--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:7.68%;--awb-margin-bottom-large:0px;--awb-spacing-left-large:0;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:7.68%;--awb-spacing-left-medium:0;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-7 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-text-color:var(--awb-custom10);">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;text-transform:uppercase;--fontSize:25;line-height:1.3;">
                                                        Complete Guides</h3>
                                                </div>
                                                <div class="fusion-text fusion-text-5"
                                                    style="--awb-text-color:var(--awb-color1);">
                                                    <p>Browse 234 Complete Guides to Healing Crystals including history,
                                                        geology, and healing.</p>
                                                </div>
                                                <div><a class="fusion-button button-flat button-small button-custom fusion-button-default button-4 fusion-button-default-span fusion-button-default-type"
                                                        style="--button_accent_color:var(--awb-custom10);--button_border_color:var(--awb-custom10);--button_accent_hover_color:var(--awb-color1);--button_border_hover_color:var(--awb-color1);--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_gradient_top_color:rgba(255,255,255,0);--button_gradient_bottom_color:rgba(255,255,255,0);--button_gradient_top_color_hover:var(--awb-color5);--button_gradient_bottom_color_hover:var(--awb-color5);"
                                                        target="_self" href="/complete-guide-to-crystals/"><span
                                                            class="fusion-button-text">View Guides</span></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-2 fusion-flex-container has-pattern-background has-mask-background hundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:2%;--awb-padding-right-medium:20px;--awb-padding-left-medium:20px;--awb-padding-right-small:10px;--awb-padding-left-small:10px;--awb-background-color:var(--awb-custom_color_1);--awb-flex-wrap:wrap;--awb-box-shadow:3px 2px 4px 0px rgba(0,0,0,.1);">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start fusion-flex-justify-content-center fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-6 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:10%;--awb-margin-top-large:0px;--awb-spacing-right-large:19.2%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:19.2%;--awb-width-medium:10%;--awb-order-medium:0;--awb-spacing-right-medium:19.2%;--awb-spacing-left-medium:19.2%;--awb-width-small:15%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-image-element sm-text-align-left"
                                                    style="text-align:right;--awb-max-width:50px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-1 hover-type-none"><a
                                                            class="fusion-no-lightbox" href="/choosing-crystals/"
                                                            target="_self" aria-label="Hand Picked Crystals 100"><img
                                                                width="100" height="100"
                                                                alt="Hand Picked Crystals healing crystals"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Hand-Picked-Crystals-100.png"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Hand-Picked-Crystals-100.png"
                                                                class="lazyload img-responsive wp-image-3115 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjEyOjM1NTQ=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjEyOjM1NTQ=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTAwIDEwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" /></a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:15%;--awb-margin-top-large:0px;--awb-spacing-right-large:12.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:0;--awb-width-medium:15%;--awb-order-medium:0;--awb-spacing-right-medium:12.8%;--awb-spacing-left-medium:0;--awb-width-small:35%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-8 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-font-size:16px;">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:16;--minFontSize:16;line-height:1.3;">
                                                        <a href="https://moonrisecrystals.com/choosing-crystals/">Hand-Selected<br />
                                                            for Beauty</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:10%;--awb-margin-top-large:0px;--awb-spacing-right-large:19.2%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:19.2%;--awb-width-medium:10%;--awb-order-medium:0;--awb-spacing-right-medium:19.2%;--awb-spacing-left-medium:19.2%;--awb-width-small:15%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:5px;--awb-spacing-left-small:5px;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-image-element sm-text-align-left"
                                                    style="text-align:right;--awb-max-width:50px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-2 hover-type-none"><a
                                                            class="fusion-no-lightbox" href="/ethical-crystals/"
                                                            target="_self"
                                                            aria-label="Ethically Sourced Crystals 100"><img width="100"
                                                                height="100"
                                                                alt="Ethically Sourced Crystals healing crystals"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Ethically-Sourced-Crystals-100.png"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Ethically-Sourced-Crystals-100.png"
                                                                class="lazyload img-responsive wp-image-3113 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjEzOjE5MTk=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjEzOjE5MTk=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTAwIDEwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" /></a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:15%;--awb-margin-top-large:0px;--awb-spacing-right-large:12.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:0;--awb-width-medium:15%;--awb-order-medium:0;--awb-spacing-right-medium:12.8%;--awb-spacing-left-medium:0;--awb-width-small:35%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-9 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-font-size:16px;">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:16;--minFontSize:16;line-height:1.3;">
                                                        <a href="https://moonrisecrystals.com/ethical-crystals/">Ethically-Sourced<br />
                                                            Supply Chain</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-10 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:10%;--awb-margin-top-large:0px;--awb-spacing-right-large:19.2%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:19.2%;--awb-width-medium:10%;--awb-order-medium:0;--awb-spacing-right-medium:19.2%;--awb-spacing-left-medium:19.2%;--awb-width-small:15%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-image-element sm-text-align-left"
                                                    style="text-align:right;--awb-max-width:50px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-3 hover-type-none"><a
                                                            class="fusion-no-lightbox"
                                                            href="/carbon-footprint-sustainability/" target="_self"
                                                            aria-label="Shipping Crystals World Wide -100"><img
                                                                width="100" height="100"
                                                                alt="Shipping Crystals World Wide healing crystals"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shipping-Crystals-World-Wide-100.png"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shipping-Crystals-World-Wide-100.png"
                                                                class="lazyload img-responsive wp-image-3117 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjE0OjE5NDI=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjE0OjE5NDI=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTAwIDEwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" /></a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-11 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:15%;--awb-margin-top-large:0px;--awb-spacing-right-large:12.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:0;--awb-width-medium:15%;--awb-order-medium:0;--awb-spacing-right-medium:12.8%;--awb-spacing-left-medium:0;--awb-width-small:35%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-10 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-font-size:16px;">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:16;--minFontSize:16;line-height:1.3;">
                                                        <a
                                                            href="https://moonrisecrystals.com/carbon-footprint-sustainability/">Carbon-Neutral<br />
                                                            Shipping</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-12 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:10%;--awb-margin-top-large:0px;--awb-spacing-right-large:19.2%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:19.2%;--awb-width-medium:10%;--awb-order-medium:0;--awb-spacing-right-medium:19.2%;--awb-spacing-left-medium:19.2%;--awb-width-small:15%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:5px;--awb-spacing-left-small:5px;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-image-element sm-text-align-left"
                                                    style="text-align:right;--awb-max-width:50px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-4 hover-type-none"><a
                                                            class="fusion-no-lightbox"
                                                            href="/carbon-footprint-sustainability/" target="_self"
                                                            aria-label="Eco Friendly Shipping Crystals 100"><img
                                                                width="100" height="100"
                                                                alt="Eco Friendly Shipping Crystals healing crystals"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Eco-Friendly-Shipping-Crystals-100.png"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Eco-Friendly-Shipping-Crystals-100.png"
                                                                class="lazyload img-responsive wp-image-3111 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjE1OjE5NDU=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjE1OjE5NDU=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTAwIDEwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" /></a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-13 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:15%;--awb-margin-top-large:0px;--awb-spacing-right-large:12.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:0;--awb-width-medium:15%;--awb-order-medium:0;--awb-spacing-right-medium:12.8%;--awb-spacing-left-medium:0;--awb-width-small:35%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:5px;--awb-spacing-left-small:0;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-11 fusion-sep-none fusion-title-text fusion-title-size-three"
                                                    style="--awb-font-size:16px;">
                                                    <h3 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:16;--minFontSize:16;line-height:1.3;">
                                                        <a
                                                            href="https://moonrisecrystals.com/carbon-footprint-sustainability/">Eco-Friendly<br />
                                                            Packaging</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container has-pattern-background has-mask-background hundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:5%;--awb-padding-bottom:1%;--awb-padding-top-small:5%;--awb-padding-bottom-small:0px;--awb-margin-bottom-small:0px;--awb-flex-wrap:wrap;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-center fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-14 fusion_builder_column_3_5 3_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:60%;--awb-margin-top-large:0px;--awb-spacing-right-large:3.2%;--awb-margin-bottom-large:0px;--awb-spacing-left-large:3.2%;--awb-width-medium:60%;--awb-order-medium:0;--awb-spacing-right-medium:3.2%;--awb-spacing-left-medium:3.2%;--awb-width-small:100%;--awb-order-small:2;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-woo-product-slider fusion-woo-slider"
                                                    style="--awb-margin-bottom:0px;">
                                                    <div class="awb-carousel awb-swiper awb-swiper-carousel fusion-carousel-title-below-image"
                                                        style="--awb-columns:3;--awb-column-spacing:10px;"
                                                        data-metacontent="yes" data-autoplay="yes" data-columns="3"
                                                        data-itemmargin="10" data-itemwidth="180" data-touchscroll="no"
                                                        data-imagesize="auto" data-scrollitems="1">
                                                        <div class="swiper-wrapper">
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/sardonyx/"
                                                                                aria-label="Sardonyx"> <img width="1200"
                                                                                    height="1200"
                                                                                    alt="Sardonyx Eye tumbled sardonyx"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Sardonyx-Eye.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjE4Ojk5MQ==-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjE4Ojk5MQ==-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/sardonyx/"
                                                                                target="_self">Sardonyx</a></h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>19.25</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/moldavite/"
                                                                                aria-label="Moldavite"> <img
                                                                                    width="1200" height="1200"
                                                                                    alt="Moldavite moldavite"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Moldavite.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjI0Ojk2MA==-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjI0Ojk2MA==-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/moldavite/"
                                                                                target="_self">Moldavite</a></h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>99.00</bdi></span>
                                                                                    &ndash; <span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>187.00</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/shattuckite/"
                                                                                aria-label="Shattuckite"> <img
                                                                                    width="1200" height="1200"
                                                                                    alt="Shattuckite shattuckite"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Shattuckite-5.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjMwOjk5Mg==-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjMwOjk5Mg==-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/shattuckite/"
                                                                                target="_self">Shattuckite</a></h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>18.50</bdi></span>
                                                                                    &ndash; <span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>40.00</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/infinite-wand/"
                                                                                aria-label="Infinite Wand"> <img
                                                                                    width="1200" height="1200"
                                                                                    alt="Infinite Wand infinite"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Infinite-Wand.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjM2Ojk5MQ==-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjM2Ojk5MQ==-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/infinite-wand/"
                                                                                target="_self">Infinite Wand</a></h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>18.00</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/pietersite-slice/"
                                                                                aria-label="Pietersite (Slice)"> <img
                                                                                    width="1200" height="1200"
                                                                                    alt="Pietersite pietersite"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pietersite.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjQyOjk2OQ==-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjQyOjk2OQ==-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/pietersite-slice/"
                                                                                target="_self">Pietersite (Slice)</a>
                                                                        </h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>40.50</bdi></span>
                                                                                    &ndash; <span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>78.00</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="swiper-slide">
                                                                <div class="fusion-clean-product-image-wrapper">
                                                                    <div class="fusion-carousel-item-wrapper">
                                                                        <div class="fusion-image-wrapper"
                                                                            aria-haspopup="true"> <a
                                                                                href="https://moonrisecrystals.com/product/pink-scolecite/"
                                                                                aria-label="Pink Scolecite"> <img
                                                                                    width="1200" height="1200"
                                                                                    alt="Pink Scolecite scolecite"
                                                                                    data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1.jpg 1200w"
                                                                                    data-sizes="auto"
                                                                                    data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1.jpg"
                                                                                    nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1.jpg 1200w"
                                                                                    nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Pink-Scolecite-1.jpg"
                                                                                    class="attachment-full size-full lazyload wp-post-image nitro-lazy"
                                                                                    decoding="async" nitro-lazy-empty
                                                                                    id="MjQ4OjEwMTQ=-1"
                                                                                    src="data:image/svg+xml;nitro-empty-id=MjQ4OjEwMTQ=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                                                <div class="cart-loading"><i
                                                                                        class="awb-icon-spinner"
                                                                                        aria-hidden="true"></i></div>
                                                                            </a> </div>
                                                                        <h4 class="fusion-carousel-title product-title">
                                                                            <a href="https://moonrisecrystals.com/product/pink-scolecite/"
                                                                                target="_self">Pink Scolecite</a></h4>
                                                                        <div class="fusion-carousel-meta">
                                                                            <div class="fusion-carousel-price"> <span
                                                                                    class="price"><span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>18.25</bdi></span>
                                                                                    &ndash; <span
                                                                                        class="woocommerce-Price-amount amount"><bdi><span
                                                                                                class="woocommerce-Price-currencySymbol">&#36;</span>22.25</bdi></span></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-15 fusion_builder_column_2_5 2_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:40%;--awb-margin-top-large:0px;--awb-spacing-right-large:4.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:4.8%;--awb-width-medium:40%;--awb-order-medium:0;--awb-spacing-right-medium:4.8%;--awb-spacing-left-medium:4.8%;--awb-width-small:100%;--awb-order-small:1;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-12 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-margin-top:0px;--awb-font-size:45px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:45;line-height:1.1;">
                                                        Find your perfect stone</h2>
                                                </div>
                                                <div class="fusion-text fusion-text-6"
                                                    style="--awb-font-size:22px;--awb-line-height:1.4;--awb-text-transform:none;--awb-margin-top:15px;--awb-margin-left:5px;">
                                                    <p>Shop our collection of stones with advanced filtering. Sort by
                                                        color, chakra, zodiac, and more. Find your favorites and
                                                        discovered new treasures.</p>
                                                </div>
                                                <div><a class="fusion-button button-flat fusion-button-default-size button-custom fusion-button-default button-5 fusion-button-default-span fusion-button-default-type"
                                                        style="--button_accent_color:var(--awb-color1);--button_border_color:var(--awb-color1);--button_accent_hover_color:var(--awb-color5);--button_border_hover_color:var(--awb-color5);--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_gradient_top_color:var(--awb-color5);--button_gradient_bottom_color:var(--awb-color5);--button_gradient_top_color_hover:rgba(255,255,255,.7);--button_gradient_bottom_color_hover:rgba(255,255,255,.7);--button_margin-top:15px;"
                                                        target="_self" href="/shop"><span
                                                            class="fusion-button-text">Shop with Advanced
                                                            Filtering</span><i
                                                            class="fa-angle-right fas button-icon-right"
                                                            aria-hidden="true"></i></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="--link_color:var(--awb-color7);--awb-background-position:right center;--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:0px;--awb-padding-right:0px;--awb-padding-bottom:0px;--awb-padding-left:0px;--awb-padding-bottom-medium:0px;--awb-padding-bottom-small:0px;--awb-margin-bottom:0px;--awb-margin-bottom-medium:0px;--awb-margin-bottom-small:0px;--awb-background-size:cover;--awb-flex-wrap:wrap;background-attachment:fixed;"
                                    data-fusion-responsive-bg="1"
                                    data-bg-small="https://moonrisecrystals.com/wp-content/uploads/1-pixel.webp"
                                    class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container has-pattern-background has-mask-background fusion-parallax-fixed hundred-percent-fullwidth non-hundred-percent-height-scrolling nitro-lazy"
                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Ethical-Crystals.webp">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-16 fusion_builder_column_3_5 3_5 fusion-flex-column fusion-animated"
                                            style="--awb-padding-top:11%;--awb-padding-right:8%;--awb-padding-bottom:9%;--awb-padding-left:8%;--awb-padding-right-medium:20%;--awb-padding-bottom-medium:10%;--awb-padding-right-small:2%;--awb-padding-bottom-small:10%;--awb-padding-left-small:5%;--awb-bg-color:rgba(255,255,255,.85);--awb-bg-color-hover:rgba(255,255,255,.85);--awb-bg-size:cover;--awb-width-large:60%;--awb-margin-top-large:0px;--awb-spacing-right-large:3.2%;--awb-margin-bottom-large:0px;--awb-spacing-left-large:3.2%;--awb-width-medium:60%;--awb-order-medium:0;--awb-spacing-right-medium:3.2%;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:3.2%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-margin-bottom-small:-21px;--awb-spacing-left-small:1.92%;"
                                            data-animationtype="slideInLeft" data-animationduration="1.2"
                                            data-animationoffset="top-into-view">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-13 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-margin-top:-10px;--awb-font-size:50px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:50;line-height:1.1;">
                                                        Ethical Crystals</h2>
                                                </div>
                                                <div class="fusion-title title fusion-title-14 fusion-sep-none fusion-title-text fusion-title-size-four"
                                                    style="--awb-text-color:var(--awb-color7);--awb-margin-bottom:0px;--awb-margin-bottom-small:0px;--awb-margin-bottom-medium:0px;--awb-font-size:37px;">
                                                    <h4 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="font-family:&quot;Allura&quot;;font-style:normal;font-weight:400;margin:0;font-size:1em;--fontSize:37;line-height:1.36;">
                                                        Know where your crystals come from.</h4>
                                                </div>
                                                <div class="fusion-text fusion-text-7"
                                                    style="--awb-text-transform:none;--awb-margin-top:15px;--awb-margin-left:5px;">
                                                    <p>Most healing crystal stores don’t know where their crystals come
                                                        from. Their main concern is the stone&#8217;s beauty and price,
                                                        and they &#8220;trust their sources.&#8221;&nbsp; At Moonrise
                                                        Crystals, we trust and then verify.&nbsp; We vet our supply
                                                        chain for real ethical concerns like:</p>
                                                </div>
                                                <ul style="--awb-line-height:27.2px;--awb-icon-width:27.2px;--awb-icon-height:27.2px;--awb-icon-margin:11.2px;--awb-content-margin:38.4px;--awb-circlecolor:var(--awb-color5);--awb-circle-yes-font-size:14.08px;"
                                                    class="fusion-checklist fusion-checklist-1 fusion-checklist-default type-icons">
                                                    <li class="fusion-li-item" style=""><span
                                                            class="icon-wrapper circle-yes"><i
                                                                class="fusion-li-icon fa-gem fas"
                                                                aria-hidden="true"></i></span>
                                                        <div class="fusion-li-item-content">Fair Wages</div>
                                                    </li>
                                                    <li class="fusion-li-item" style=""><span
                                                            class="icon-wrapper circle-yes"><i
                                                                class="fusion-li-icon fa-gem fas"
                                                                aria-hidden="true"></i></span>
                                                        <div class="fusion-li-item-content">Safe Factory Conditions
                                                        </div>
                                                    </li>
                                                    <li class="fusion-li-item" style=""><span
                                                            class="icon-wrapper circle-yes"><i
                                                                class="fusion-li-icon fa-gem fas"
                                                                aria-hidden="true"></i></span>
                                                        <div class="fusion-li-item-content">
                                                            <p>Environmentally Friendly Mining</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div class="fusion-text fusion-text-8"
                                                    style="--awb-text-transform:none;--awb-margin-top:15px;">
                                                    <p>Our <a href="/ethical-crystals/" target="_blank"
                                                            rel="noopener">ethical sourcing of crystals</a> is based on
                                                        a deep understanding of geology, geography, <a
                                                            href="/ethical-mining/" target="_blank"
                                                            rel="noopener">mining</a>, and <a href="/ethical-lapidary/"
                                                            target="_blank" rel="noopener">polishing techniques</a>, as
                                                        well as analyzing topics like child and slave labor statistics.
                                                        We know the current conflict zones and political realities that
                                                        impact our supply chains. We also explore complex issues like
                                                        indigenous land rights and how financially empowering women
                                                        transforms communities. Our ethical supply chain is not perfect,
                                                        but it’s real. It’s a work-in-progress and a labor-of-love.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-17 fusion_builder_column_2_5 2_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:40%;--awb-margin-top-large:0px;--awb-spacing-right-large:4.8%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:4.8%;--awb-width-medium:40%;--awb-order-medium:0;--awb-spacing-right-medium:4.8%;--awb-spacing-left-medium:4.8%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="--awb-background-position:right center;--awb-border-color:var(--awb-color5);--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:0px;--awb-padding-right:0px;--awb-padding-bottom:0px;--awb-padding-left:0px;--awb-padding-bottom-medium:0px;--awb-padding-bottom-small:0px;--awb-margin-bottom:0px;--awb-margin-bottom-medium:0px;--awb-margin-bottom-small:0px;--awb-background-size:cover;--awb-flex-wrap:wrap;background-attachment:fixed;"
                                    data-fusion-responsive-bg="1"
                                    data-bg-small="https://moonrisecrystals.com/wp-content/uploads/1-pixel.webp"
                                    class="fusion-fullwidth fullwidth-box fusion-builder-row-5 fusion-flex-container has-pattern-background has-mask-background fusion-parallax-fixed hundred-percent-fullwidth non-hundred-percent-height-scrolling nitro-lazy"
                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Crystal-Healing.webp">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-18 fusion_builder_column_2_5 2_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:40%;--awb-margin-top-large:0px;--awb-spacing-right-large:4.8%;--awb-margin-bottom-large:0px;--awb-spacing-left-large:4.8%;--awb-width-medium:40%;--awb-order-medium:0;--awb-spacing-right-medium:4.8%;--awb-spacing-left-medium:4.8%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-19 fusion_builder_column_3_5 3_5 fusion-flex-column fusion-animated"
                                            style="--awb-padding-top:13%;--awb-padding-right:8%;--awb-padding-bottom:13%;--awb-padding-left:9%;--awb-padding-right-medium:20%;--awb-padding-bottom-medium:10%;--awb-padding-top-small:8%;--awb-padding-right-small:5%;--awb-padding-bottom-small:15%;--awb-padding-left-small:5%;--awb-bg-color:rgba(255,255,255,.85);--awb-bg-color-hover:rgba(255,255,255,.85);--awb-bg-size:cover;--awb-width-large:60%;--awb-margin-top-large:0px;--awb-spacing-right-large:3.2%;--awb-margin-bottom-large:0px;--awb-spacing-left-large:3.2%;--awb-width-medium:60%;--awb-order-medium:0;--awb-spacing-right-medium:3.2%;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:3.2%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-margin-bottom-small:-21px;--awb-spacing-left-small:1.92%;"
                                            data-animationtype="slideInRight" data-animationduration="1.2"
                                            data-animationoffset="top-into-view"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-15 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-margin-top:0px;--awb-font-size:45px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:45;line-height:1.1;">
                                                        Crystal Healing</h2>
                                                </div>
                                                <div class="fusion-text fusion-text-9"
                                                    style="--awb-font-size:24px;--awb-line-height:1.4;--awb-text-transform:none;--awb-margin-top:15px;--awb-margin-left:5px;">
                                                    <p><a href="/do-crystals-work/" target="_blank" rel="noopener">Do
                                                            crystals really work?&nbsp; Learn more here.</a></p>
                                                </div>
                                                <div class="fusion-text fusion-text-10"
                                                    style="--awb-text-transform:none;">
                                                    <p style="text-align:left;">Moonrise Crystals offers a free
                                                        encyclopedia of information in our Complete Guides.&nbsp; Each
                                                        of the 200+ Guides provides in-depth scientific and historical
                                                        research, as well as spiritual intuition for healing crystal
                                                        meanings and properties.&nbsp; Or browse other research articles
                                                        that offer guidance on topics like how to cleanse your crystals.
                                                    </p>
                                                </div>
                                                <div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start fusion-flex-content-wrap"
                                                    style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                                    <div class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-0 fusion_builder_column_inner_1_2 1_2 fusion-flex-column"
                                                        style="--awb-bg-size:cover;--awb-width-large:50%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:0;--awb-spacing-left-small:0;"
                                                        data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                                        data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                                        <div
                                                            class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                            <div><a class="fusion-button button-flat button-medium button-default fusion-button-default button-6 fusion-button-default-span fusion-button-default-type"
                                                                    style="--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_margin-top:20px;"
                                                                    target="_self"
                                                                    href="https://moonrisecrystals.com/complete-guide-to-crystals/"><span
                                                                        class="fusion-button-text">Complete
                                                                        Guides</span></a></div>
                                                        </div>
                                                    </div>
                                                    <div class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-1 fusion_builder_column_inner_1_2 1_2 fusion-flex-column"
                                                        style="--awb-bg-size:cover;--awb-width-large:50%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:0;--awb-margin-bottom-small:0;--awb-spacing-left-small:0;"
                                                        data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                                        data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                                        <div
                                                            class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                            <div><a class="fusion-button button-flat button-medium button-default fusion-button-default button-7 fusion-button-default-span fusion-button-default-type"
                                                                    style="--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_margin-top:20px;"
                                                                    target="_self"
                                                                    href="https://moonrisecrystals.com/crystal-articles/"><span
                                                                        class="fusion-button-text">Other
                                                                        Articles</span></a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-6 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="--link_hover_color:var(--awb-custom10);--link_color:var(--awb-color2);--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:5%;--awb-padding-bottom:0px;--awb-margin-bottom:0px;--awb-background-color:var(--awb-color5);--awb-flex-wrap:wrap;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start fusion-flex-content-wrap"
                                        style="max-width:1274px;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-20 fusion_builder_column_1_1 1_1 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:100%;--awb-margin-top-large:0px;--awb-spacing-right-large:1.92%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:1.92%;--awb-width-medium:100%;--awb-order-medium:0;--awb-spacing-right-medium:1.92%;--awb-spacing-left-medium:1.92%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-16 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-three"
                                                    style="--awb-text-color:var(--awb-color1);--awb-margin-top:-10px;--awb-font-size:40px;">
                                                    <h3 class="fusion-title-heading title-heading-center fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:40;line-height:1.3;">
                                                        What are You Trying to Heal?</h3>
                                                </div>
                                                <div class="fusion-text fusion-text-11"
                                                    style="--awb-text-transform:none;--awb-text-color:var(--awb-color1);">
                                                    <p>Crystals are psychological tools that can be used for physical,
                                                        mental, emotional, and spiritual wellness. By touching a stone,
                                                        we focus our attention on the topics that matter to us. A
                                                        crystal for peace reminds us to be patient, calm, and
                                                        reasonable. A crystal for luck encourages us to notice good
                                                        opportunities. You can use crystals to empower and heal yourself
                                                        or, dare to go a step further and use them to make the world a
                                                        better place.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-7 fusion-flex-container has-pattern-background has-mask-background hundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:0px;--awb-padding-right-small:0px;--awb-padding-left-small:0px;--awb-margin-top:-30px;--awb-background-color:var(--awb-color5);--awb-flex-wrap:wrap;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start fusion-flex-content-wrap"
                                        style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-21 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:0;--awb-spacing-left-small:5px;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div style="--awb-mask-url:url(&quot;data:image/gif;base64,R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==&quot;);--awb-mask-size:75%;--awb-caption-title-color:var(--awb-color1);--awb-caption-text-color:var(--awb-color2);--awb-caption-border-color:var(--awb-color1);--awb-caption-overlay-color:var(--awb-color5);--awb-max-width:350px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:20px;--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);"
                                                    class="fusion-image-element nitro-lazy"
                                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/plugins/fusion-builder//assets/images/masks/mask-5.svg">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-5 awb-imageframe-style awb-imageframe-style-resa has-mask"><a
                                                            class="fusion-no-lightbox"
                                                            href="/crystals-spiritual-healing/" target="_self"
                                                            aria-label="Blue Turquoise"><img width="600" height="600"
                                                                alt="Blue Turquoise blue turquoise"
                                                                data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise.jpg 1200w"
                                                                data-sizes="auto"
                                                                data-orig-sizes="(max-width: 640px) 100vw, (max-width: 1919px) 600px,(min-width: 1920px) 25vw"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-600x600.jpg"
                                                                nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise.jpg 1200w"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Blue-Turquoise-600x600.jpg"
                                                                class="lazyload img-responsive wp-image-3002 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjYwOjQ1ODk=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjYwOjQ1ODk=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                            <div class="awb-imageframe-caption-container">
                                                                <div class="awb-imageframe-caption">
                                                                    <h2 class="awb-imageframe-caption-title">Spiritual
                                                                        Healing</h2>
                                                                    <p class="awb-imageframe-caption-text">Explore</p>
                                                                </div>
                                                            </div>
                                                        </a></span></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-22 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:0;--awb-spacing-left-small:5px;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div style="--awb-mask-url:url(&quot;data:image/gif;base64,R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==&quot;);--awb-mask-size:75%;--awb-caption-title-color:var(--awb-color1);--awb-caption-text-color:var(--awb-color2);--awb-caption-border-color:var(--awb-color1);--awb-caption-overlay-color:var(--awb-color5);--awb-max-width:350px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:20px;--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);"
                                                    class="fusion-image-element nitro-lazy"
                                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/plugins/fusion-builder//assets/images/masks/mask-5.svg">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-6 awb-imageframe-style awb-imageframe-style-resa has-mask"><a
                                                            class="fusion-no-lightbox"
                                                            href="/crystals-emotional-healing/" target="_self"
                                                            aria-label="Carnelian sm"><img width="400" height="400"
                                                                alt="Carnelian healing crystals"
                                                                data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm.jpg 400w"
                                                                data-sizes="auto"
                                                                data-orig-sizes="(max-width: 640px) 100vw, 400px"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm.jpg"
                                                                nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm.jpg 400w"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Carnelian-sm.jpg"
                                                                class="lazyload img-responsive wp-image-13366 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjYwOjgzMzk=-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjYwOjgzMzk=-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNDAwIDQwMCIgd2lkdGg9IjQwMCIgaGVpZ2h0PSI0MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" />
                                                            <div class="awb-imageframe-caption-container">
                                                                <div class="awb-imageframe-caption">
                                                                    <h2 class="awb-imageframe-caption-title">Emotional
                                                                        Healing</h2>
                                                                    <p class="awb-imageframe-caption-text">Explore</p>
                                                                </div>
                                                            </div>
                                                        </a></span></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-23 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:0;--awb-spacing-left-small:5px;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div style="--awb-mask-url:url(&quot;data:image/gif;base64,R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==&quot;);--awb-mask-size:75%;--awb-caption-title-color:var(--awb-color1);--awb-caption-text-color:var(--awb-color2);--awb-caption-border-color:var(--awb-color1);--awb-caption-overlay-color:var(--awb-color5);--awb-max-width:350px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:20px;--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);"
                                                    class="fusion-image-element nitro-lazy"
                                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/plugins/fusion-builder//assets/images/masks/mask-5.svg">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-7 awb-imageframe-style awb-imageframe-style-resa has-mask"><a
                                                            class="fusion-no-lightbox"
                                                            href="/crystals-physical-healing/" target="_self"
                                                            aria-label="Black Tourmaline Disc"><img width="1024"
                                                                height="1024"
                                                                alt="Black Tourmaline Disc black tourmaline disc"
                                                                data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc.jpg 1200w"
                                                                data-sizes="auto"
                                                                data-orig-sizes="(max-width: 640px) 100vw, (max-width: 1919px) 600px,(min-width: 1920px) 25vw"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-1024x1024.jpg"
                                                                nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc.jpg 1200w"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Black-Tourmaline-Disc-1024x1024.jpg"
                                                                class="lazyload img-responsive wp-image-1764 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjYwOjEyNDgx-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjYwOjEyNDgx-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                            <div class="awb-imageframe-caption-container">
                                                                <div class="awb-imageframe-caption">
                                                                    <h2 class="awb-imageframe-caption-title">Physical
                                                                        Healing</h2>
                                                                    <p class="awb-imageframe-caption-text">Explore</p>
                                                                </div>
                                                            </div>
                                                        </a></span></div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-24 fusion_builder_column_1_4 1_4 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:5px;--awb-margin-bottom-large:0px;--awb-spacing-left-large:5px;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:5px;--awb-margin-bottom-medium:0;--awb-spacing-left-medium:5px;--awb-width-small:50%;--awb-order-small:0;--awb-spacing-right-small:5px;--awb-margin-bottom-small:0;--awb-spacing-left-small:5px;"
                                            data-motion-effects="[{&quot;type&quot;:&quot;&quot;,&quot;scroll_type&quot;:&quot;transition&quot;,&quot;scroll_direction&quot;:&quot;up&quot;,&quot;transition_speed&quot;:&quot;1&quot;,&quot;fade_type&quot;:&quot;in&quot;,&quot;scale_type&quot;:&quot;up&quot;,&quot;initial_scale&quot;:&quot;1&quot;,&quot;max_scale&quot;:&quot;1.5&quot;,&quot;min_scale&quot;:&quot;0.5&quot;,&quot;initial_rotate&quot;:&quot;0&quot;,&quot;end_rotate&quot;:&quot;30&quot;,&quot;initial_blur&quot;:&quot;0&quot;,&quot;end_blur&quot;:&quot;3&quot;,&quot;start_element&quot;:&quot;top&quot;,&quot;start_viewport&quot;:&quot;bottom&quot;,&quot;end_element&quot;:&quot;bottom&quot;,&quot;end_viewport&quot;:&quot;top&quot;,&quot;mouse_effect&quot;:&quot;track&quot;,&quot;mouse_effect_direction&quot;:&quot;opposite&quot;,&quot;mouse_effect_speed&quot;:&quot;2&quot;,&quot;infinite_animation&quot;:&quot;float&quot;,&quot;infinite_animation_speed&quot;:&quot;2&quot;}]"
                                            data-scroll-devices="small-visibility,medium-visibility,large-visibility">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div style="--awb-mask-url:url(&quot;data:image/gif;base64,R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==&quot;);--awb-mask-size:75%;--awb-caption-title-color:var(--awb-color1);--awb-caption-text-color:var(--awb-color2);--awb-caption-border-color:var(--awb-color1);--awb-caption-overlay-color:var(--awb-color5);--awb-max-width:350px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:20px;--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);"
                                                    class="fusion-image-element nitro-lazy"
                                                    nitro-lazy-bg="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/plugins/fusion-builder//assets/images/masks/mask-5.svg">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-8 awb-imageframe-style awb-imageframe-style-resa has-mask"><a
                                                            class="fusion-no-lightbox" href="/crystals-world-healing/"
                                                            target="_self" aria-label="Yellow Opal"><img width="600"
                                                                height="600" alt="Yellow Opal tumbled yellow opal"
                                                                data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2.jpg 1200w"
                                                                data-sizes="auto"
                                                                data-orig-sizes="(max-width: 640px) 100vw, (max-width: 1919px) 600px,(min-width: 1920px) 25vw"
                                                                data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-600x600.jpg"
                                                                nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-800x800.jpg 800w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2.jpg 1200w"
                                                                nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Yellow-Opal-2-600x600.jpg"
                                                                class="lazyload img-responsive wp-image-16079 nitro-lazy"
                                                                decoding="async" nitro-lazy-empty id="MjYwOjE2NTM4-1"
                                                                src="data:image/svg+xml;nitro-empty-id=MjYwOjE2NTM4-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTIwMCAxMjAwIiB3aWR0aD0iMTIwMCIgaGVpZ2h0PSIxMjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" />
                                                            <div class="awb-imageframe-caption-container">
                                                                <div class="awb-imageframe-caption">
                                                                    <h2 class="awb-imageframe-caption-title">World
                                                                        Healing</h2>
                                                                    <p class="awb-imageframe-caption-text">Explore</p>
                                                                </div>
                                                            </div>
                                                        </a></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-8 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="--awb-border-radius-top-left:0px;--awb-border-radius-top-right:0px;--awb-border-radius-bottom-right:0px;--awb-border-radius-bottom-left:0px;--awb-padding-top:5%;--awb-padding-bottom:4%;--awb-flex-wrap:wrap;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-center fusion-flex-content-wrap"
                                        style="max-width:1274px;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-25 fusion_builder_column_1_5 1_5 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:20%;--awb-margin-top-large:0px;--awb-spacing-right-large:9.6%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:9.6%;--awb-width-medium:20%;--awb-order-medium:0;--awb-spacing-right-medium:9.6%;--awb-spacing-left-medium:9.6%;--awb-width-small:33.3333333333%;--awb-order-small:0;--awb-spacing-right-small:5.76%;--awb-spacing-left-small:5.76%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-image-element "
                                                    style="--awb-max-width:250px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                    <span
                                                        class=" fusion-imageframe imageframe-none imageframe-9 hover-type-none"
                                                        style="border-radius:50%;"><img width="800" height="800"
                                                            alt="Julie Owner Of Moonrise Crystals ethical crystals"
                                                            title="Julie owner of Moonrise Crystals"
                                                            data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals.jpg 800w"
                                                            data-sizes="auto"
                                                            data-orig-sizes="(max-width: 640px) 100vw, 400px"
                                                            data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals.jpg"
                                                            nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-200x200.jpg 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-400x400.jpg 400w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals-600x600.jpg 600w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals.jpg 800w"
                                                            nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/Julie-owner-of-Moonrise-Crystals.jpg"
                                                            class="lazyload img-responsive wp-image-1983 nitro-lazy"
                                                            decoding="async" nitro-lazy-empty id="MjYwOjE5NzIx-1"
                                                            src="data:image/svg+xml;nitro-empty-id=MjYwOjE5NzIx-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgODAwIDgwMCIgd2lkdGg9IjgwMCIgaGVpZ2h0PSI4MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PC9zdmc+" /></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-26 fusion_builder_column_1_3 1_3 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:33.3333333333%;--awb-margin-top-large:0px;--awb-spacing-right-large:5.76%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:5.76%;--awb-width-medium:33.3333333333%;--awb-order-medium:0;--awb-spacing-right-medium:5.76%;--awb-spacing-left-medium:5.76%;--awb-width-small:66.6666666667%;--awb-order-small:0;--awb-spacing-right-small:2.88%;--awb-spacing-left-small:2.88%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-title title fusion-title-17 fusion-sep-none fusion-title-text fusion-title-size-two"
                                                    style="--awb-margin-top:0px;--awb-font-size:30px;">
                                                    <h2 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="margin:0;font-size:1em;--fontSize:30;line-height:1.1;">
                                                        Moonrise Crystal Founder</h2>
                                                </div>
                                                <div class="fusion-title title fusion-title-18 fusion-sep-none fusion-title-text fusion-title-size-four"
                                                    style="--awb-text-color:var(--awb-color7);--awb-margin-top:0px;--awb-margin-bottom-small:0px;--awb-margin-bottom-medium:0px;--awb-font-size:30px;">
                                                    <h4 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                        style="font-family:&quot;Allura&quot;;font-style:normal;font-weight:400;margin:0;font-size:1em;--fontSize:30;line-height:1.36;">
                                                        Meet Julie</h4>
                                                </div>
                                                <div><a class="fusion-button button-flat button-small button-default fusion-button-default button-8 fusion-button-default-span fusion-button-default-type"
                                                        style="--button-border-radius-top-left:0;--button-border-radius-top-right:0;--button-border-radius-bottom-right:0;--button-border-radius-bottom-left:0;--button_margin-top:10px;"
                                                        target="_self"
                                                        href="https://moonrisecrystals.com/my-journey/"><span
                                                            class="fusion-button-text">Julie&#8217;s Journey</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fusion-layout-column fusion_builder_column fusion-builder-column-27 fusion-flex-column"
                                            style="--awb-bg-size:cover;--awb-width-large:45%;--awb-margin-top-large:0px;--awb-spacing-right-large:4.26666666667%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:4.26666666667%;--awb-width-medium:45%;--awb-order-medium:0;--awb-spacing-right-medium:4.26666666667%;--awb-spacing-left-medium:4.26666666667%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                            <div
                                                class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                <div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-center fusion-flex-content-wrap"
                                                    style="width:104% !important;max-width:104% !important;margin-left:calc(-4% / 2);margin-right:calc(-4% / 2);">
                                                    <div class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-2 fusion_builder_column_inner_1_4 1_4 fusion-flex-column"
                                                        style="--awb-bg-size:cover;--awb-width-large:25%;--awb-margin-top-large:0px;--awb-spacing-right-large:7.68%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:7.68%;--awb-width-medium:25%;--awb-order-medium:0;--awb-spacing-right-medium:7.68%;--awb-spacing-left-medium:7.68%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                                        <div
                                                            class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                            <div class="fusion-image-element "
                                                                style="--awb-max-width:150px;--awb-caption-title-font-family:var(--h2_typography-font-family);--awb-caption-title-font-weight:var(--h2_typography-font-weight);--awb-caption-title-font-style:var(--h2_typography-font-style);--awb-caption-title-size:var(--h2_typography-font-size);--awb-caption-title-transform:var(--h2_typography-text-transform);--awb-caption-title-line-height:var(--h2_typography-line-height);--awb-caption-title-letter-spacing:var(--h2_typography-letter-spacing);">
                                                                <span
                                                                    class=" fusion-imageframe imageframe-none imageframe-10 hover-type-none"><img
                                                                        width="299" height="57"
                                                                        alt="Stars healing crystals" title="5-stars"
                                                                        data-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars-200x38.png 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars.png 299w"
                                                                        data-sizes="auto"
                                                                        data-orig-sizes="(max-width: 640px) 100vw, 299px"
                                                                        data-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars.png"
                                                                        nitro-lazy-srcset="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars-200x38.png 200w, https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars.png 299w"
                                                                        nitro-lazy-src="https://cdn-kepfd.nitrocdn.com/yhFRSzwhyHaKZOIOsRGVmHbaFTltymOf/assets/images/optimized/rev-0f8fe5a/moonrisecrystals.com/wp-content/uploads/5-stars.png"
                                                                        class="lazyload img-responsive wp-image-12794 nitro-lazy"
                                                                        decoding="async" nitro-lazy-empty
                                                                        id="MjYwOjI0NjQ2-1"
                                                                        src="data:image/svg+xml;nitro-empty-id=MjYwOjI0NjQ2-1;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMjk5IDU3IiB3aWR0aD0iMjk5IiBoZWlnaHQ9IjU3IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjwvc3ZnPg==" /></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-3 fusion_builder_column_inner_3_4 3_4 fusion-flex-column"
                                                        style="--awb-bg-size:cover;--awb-width-large:75%;--awb-margin-top-large:0px;--awb-spacing-right-large:2.56%;--awb-margin-bottom-large:20px;--awb-spacing-left-large:2.56%;--awb-width-medium:75%;--awb-order-medium:0;--awb-spacing-right-medium:2.56%;--awb-spacing-left-medium:2.56%;--awb-width-small:100%;--awb-order-small:0;--awb-spacing-right-small:1.92%;--awb-spacing-left-small:1.92%;">
                                                        <div
                                                            class="fusion-column-wrapper fusion-column-has-shadow fusion-flex-justify-content-flex-start fusion-content-layout-column">
                                                            <div class="fusion-title title fusion-title-19 fusion-sep-none fusion-title-text fusion-title-size-four"
                                                                style="--awb-text-color:var(--awb-color5);--awb-margin-top:20px;--awb-font-size:23px;">
                                                                <h4 class="fusion-title-heading title-heading-left fusion-responsive-typography-calculated"
                                                                    style="margin:0;font-size:1em;--fontSize:23;--minFontSize:23;line-height:1.36;">
                                                                    Over <strong>7000</strong> 5-Star Product Reviews!
                                                                </h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="fusion-testimonials classic fusion-testimonials-1"
                                                    style="--awb-textcolor:#4a4e57;--awb-backgroundcolor:#f9f9fb;"
                                                    data-random="0" data-speed="4000">
                                                    <div class="reviews">
                                                        <div class="review active-testimonial no-avatar">
                                                            <blockquote><q class="fusion-clearfix"><span
                                                                        style="font-size:24px;">The whole experience
                                                                        from start to finish was soothing to the
                                                                        heart.</span></q></blockquote>
                                                            <div class="author"><span
                                                                    class="company-name"><strong>Deirdre M</strong>,
                                                                    <span>Ohio</span></span></div>
                                                        </div>
                                                        <div class="review no-avatar">
                                                            <blockquote><q class="fusion-clearfix"><span
                                                                        style="font-size:24px;">Julie is patient,
                                                                        understanding, kind and professional.</span></q>
                                                            </blockquote>
                                                            <div class="author"><span class="company-name"><strong>Lisa
                                                                        B.</strong>, <span>Shorewood, IL</span></span>
                                                            </div>
                                                        </div>
                                                        <div class="review no-avatar">
                                                            <blockquote><q class="fusion-clearfix"><span
                                                                        style="font-size:24px;">Moonrise Crystals is
                                                                        truly a gem. Julie, is helpful, knowledgeable
                                                                        and understanding.</span></q></blockquote>
                                                            <div class="author"><span
                                                                    class="company-name"><strong>Khairi J.</strong>,
                                                                    <span>Singapore</span></span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <script nitro-exclude>
                        document.cookie = 'nitroCachedPage=' + (!window.NITROPACK_STATE ? '0' : '1') + '; path=/; SameSite=Lax';
                    </script>
                    <script nitro-exclude>
                        if (!window.NITROPACK_STATE || window.NITROPACK_STATE != 'FRESH') {
                            var proxyPurgeOnly = 0;
                            if (typeof navigator.sendBeacon !== 'undefined') {
                                var nitroData = new FormData(); nitroData.append('nitroBeaconUrl', 'aHR0cHM6Ly9tb29ucmlzZWNyeXN0YWxzLmNvbS8='); nitroData.append('nitroBeaconCookies', 'W10='); nitroData.append('nitroBeaconHash', '159761843f8f4c844fe71107d75b96ca92699d0382b8081fbca977471407e55fc5e0f0a98b939a0b8cff52c09ec9b277101ee4afe93641d06ec7b23f949927b5'); nitroData.append('proxyPurgeOnly', ''); nitroData.append('layout', 'home'); navigator.sendBeacon(location.href, nitroData);
                            } else {
                                var xhr = new XMLHttpRequest(); xhr.open('POST', location.href, true); xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); xhr.send('nitroBeaconUrl=aHR0cHM6Ly9tb29ucmlzZWNyeXN0YWxzLmNvbS8=&nitroBeaconCookies=W10=&nitroBeaconHash=159761843f8f4c844fe71107d75b96ca92699d0382b8081fbca977471407e55fc5e0f0a98b939a0b8cff52c09ec9b277101ee4afe93641d06ec7b23f949927b5&proxyPurgeOnly=&layout=home');
                            }
                        }
                    </script>
                </div>
            </main>
            
            
@endsection

@push('script')
    {{-- Owl Carousel --}}
    <script src="{{asset('public/assets/front-end')}}/js/owl.carousel.min.js"></script>

    <script>
        $('#flash-deal-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 20,
            nav: true,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 3
                }
            }
        })

        $('#web-feature-deal-slider').owlCarousel({
            loop: false,
            autoplay: true,
            margin: 20,
            nav: false,
            //navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 2
                }
            }
        })

        $('#new-arrivals-product').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 20,
            nav: true,
            navText: ["<i class='czi-arrow-{{Session::get('direction') === "rtl" ? 'right' : 'left'}}'></i>", "<i class='czi-arrow-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 4
                }
            }
        })
    </script>
    <script>
        $('#featured_products_list').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 20,
            nav: true,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 3
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 5
                },
                //Extra extra large
                1400: {
                    items: 5
                }
            }
        });
    </script>
    <script>
        $('#brands-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 10,
            nav: false,
            '{{session('direction')}}': true,
            dots: true,
            autoplayHoverPause: true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 4
                },
                360: {
                    items: 5
                },
                375: {
                    items: 5
                },
                540: {
                    items: 5
                },
                //Small
                576: {
                    items: 6
                },
                //Medium
                768: {
                    items: 7
                },
                //Large
                992: {
                    items: 9
                },
                //Extra large
                1200: {
                    items: 11
                },
                //Extra extra large
                1400: {
                    items: 12
                }
            }
        })
    </script>

    <script>
        $('#category-slider, #top-seller-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 20,
            nav: false,
            // navText: ["<i class='czi-arrow-left'></i>","<i class='czi-arrow-right'></i>"],
            dots: true,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 3
                },
                375: {
                    items: 3
                },
                540: {
                    items: 4
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 6
                },
                //Large
                992: {
                    items: 8
                },
                //Extra large
                1200: {
                    items: 10
                },
                //Extra extra large
                1400: {
                    items: 11
                }
            }
        })
    </script>
@endpush

